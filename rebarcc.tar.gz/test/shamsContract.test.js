'use strict';
const { expect } = require('chai');
const ctx = { stub: { getState: async () => Buffer.from(''), putState: async () => {} } };
const ContractClass = require('../lib/shamsContract');
describe('shamsContract', () => {
    it('should instantiate', async () => {
        const inst = new ContractClass();
        expect(inst).to.be.an('object');
    });
});
